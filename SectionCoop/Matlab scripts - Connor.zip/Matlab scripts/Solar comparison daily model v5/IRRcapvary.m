% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;           % cost for pure thermal
CpMWPVT = 2.625e6;         % cost for pvt 2.625
CpMWFarm = 0;        % cost for solar farm set to 0.674e6 for inclusion
Cpmborehole = 42;           % cost per m borehole
CpMWhelec = 198; 
%45*1.4;        % estimated cost per MWh electricity (198 2019,202 2020, 219 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy


% set SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];
pv_1MW_HH = pv_1MW.*1.1;
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
%pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
DHW = max(DHW,0);
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2).*(18/20);
SH = SH.*0.5; % power to energy
SH = sum(reshape(SH,48,365)).';
SH = max(SH,0);

% electricity profile
elecdemand = readmatrix('HH_electricity');
elecdemand = elecdemand(2:17521,2);

% initialise NPV vectors
maxheatcap = 15; %MW
step = 0.01;
heatcap = 0:step:maxheatcap;
[height, length] = size(heatcap);
initialcost = heatcap.*CpMWPVT;
farmsaving = heatcap.*CpMWFarm;

% cost over 30 years
designlifetime = 25; % in years

i = 0;

excessDHWtot = zeros(1,maxheatcap/step);
excessSHtot = zeros(1,maxheatcap/step);
heat2ground = zeros(1,maxheatcap/step);
elecsavingdirect = zeros(1,maxheatcap/step);
elecsold = zeros(1,maxheatcap/step);

for heatcap = 0:step:maxheatcap % MW of solar thermal panels
    
    i = i + 1;
    
    % panel heat
    PH = pvt_1MW.*heatcap;
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot(i) = sum(excessDHW);
    excessSHtot(i) = sum(excessSH);
    heat2ground(i) = sum(p2g);
    %test = SH - excessSH;
    
    elecnet = pv_1MW_HH.*heatcap - elecdemand;
    elecsell = max(elecnet,0);
    elecsold(i) = sum(elecsell);
    elecneg = min(elecnet,0);
    elecsavingvector = elecneg + elecdemand;
    elecsavingdirect(i) = sum(elecsavingvector);
    
end

SHsatisfied = sum(SH) - excessSHtot;
DHWsatisfied = sum(DHW) - excessDHWtot;
