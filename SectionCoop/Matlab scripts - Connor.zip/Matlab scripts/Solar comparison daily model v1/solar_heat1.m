% add relevant paths
addpath 'C:\Users\User\Documents\3YP\data files'

% load 1MW pv profile
pv_1MW = readmatrix('pv_d_energy');
pv_1MW = pv_1MW(:,2);

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW(:,2) = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('daily_DHW_power');
DHW = DHW.';
%DHW = DHW.*24;  % power to energy
SH = readmatrix('heating_daily_power');
SH = SH(:,2);
%SH = SH.*3; % the original was in electricity not heat
%SH = SH.*24; % power to energy
SH = SH(1:365,:);

% scale heat demands
DHW = DHW.*((5.2e3)/sum(DHW));
SH = SH.*((21.1e3)/sum(SH));

% total heating demands
DHWtot = sum(DHW);
SHtot = sum(SH);

% define amounts of heat
% initialise vectors
hmax = 18;
usefulDHW = zeros(1,hmax+1);
usefulSH = zeros(1,hmax+1);
heat2ground = zeros(1,hmax+1);

for heat = 0:hmax % MW of solar thermal panels
    
    % panel heat
    PH = st_1MW.*heat;
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessSHtot = sum(excessSH);
    excessDHWtot = sum(excessDHW);
    
    usefulDHW(heat+1) = DHWtot - excessDHWtot;
    usefulSH(heat+1) = SHtot - excessSHtot;
    heat2ground(heat+1) = sum(p2g);
    
end

figure
plot(0:hmax,usefulDHW,'g');
hold on
plot(0:hmax,usefulSH,'r');
hold off
xlabel('Total Thermal Panel Capacity (MW)')
ylabel('Useful Heat (MWh per year)')
legend({'Hot Water','Space Heating'},'Location','southeast')
