% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% capacity
Cap = 6;       % MW

% lifespan and degradation
lifespan = 25;   % expected years of operation
deg = 0.994;      % yearly degradation factor (capacity drop)

% costs
CpMWFarm = 0.674e6;        % cost for solar farm
CpMWhelec = 198; 
%45*1.4;        % estimated cost per MWh electricity (198 2019,202 2020, 219 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy

% load data
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];

% revenue
year1rev = sum(pv_1MW)*Cap*CpMWhelecsell;
rev = zeros(1,lifespan);  % initialise revenue vector, holds total for each year of operation

for y = 1:1:lifespan
    rev(y) = year1rev*(deg^(y-1));  % gives revenue of that year 
end

% costs
initialcost = CpMWFarm*Cap;

% net present value
Dmax = 0.2;
Dstep = 0.001;
Dreal = 0:Dstep:Dmax;
NPV = zeros(1,Dmax/Dstep);
iter = 0;
t = 1:1:lifespan;


for Dreal = 0:Dstep:Dmax
    iter = iter+1;
    PVrev = zeros(1,lifespan);
    for y = 1:1:lifespan
        Drealfactor = (1+(Dreal)).^(-y);
        PVrev(y) = year1rev*(deg^(y-1))*Drealfactor;  % gives PV of revenue of that year 
    end
    NPV(iter) = sum(PVrev) - initialcost;
end

figure
plot(0:Dstep*100:Dmax*100,NPV)
xlabel('Real Discount Rate (%)')
ylabel('Net Present Value (Millions of Pounds)')
title('Net Present Value for a 6MW Solar Farm Installation')
grid on