% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;            % cost for pure thermal
CpMWPVT = 2.625e6;         % cost for pvt
CpMWFarm = 0.674e6;        % cost for solar farm

% set cost per MWh electricity
CpMWh = 45*1.5;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2);
pv_1MW = [pv_1MW; 0];
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';
sum(pv_1MW)


% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW(:,2) = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2);
SH = SH.*0.5; % power to energy
SH = sum(reshape(SH,48,365)).';

% scale heat demands
%DHW = DHW.*((5.2e3)/sum(DHW));
%SH = SH.*((21.1e3)/sum(SH));

% total heating demands
DHWtot = sum(DHW);
SHtot = sum(SH);

% define amounts of heat
% initialise vectors
hmax = 15;
heat = 0:0.1:hmax;
heatlength = length(heat);
excessDHWtot = zeros(1,heatlength);
excessSHtot = zeros(1,heatlength);
heat2ground = zeros(1,heatlength);
Thsystemcost = zeros(1,heatlength);    % for pure thermal
PVTsystemcost = zeros(1,heatlength);    % for pvt

for i = 1:heatlength % MW of solar thermal panels
    
    % panel heat
    PH = st_1MW.*heat(i);
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot(i) = sum(excessDHW);
    excessSHtot(i) = sum(excessSH);
    heat2ground(i) = sum(p2g);
    
    Thsystemcost(i) = heat(i)*CpMWTh;
    PVTsystemcostw(i) = heat(i)*CpMWPVT;
    
end

% electrical energy costs
DHWenergy = excessDHWtot./2.2;
SHenergy = excessSHtot./3.2;

DHWcost = DHWenergy.*CpMWh;
SHcost = SHenergy.*CpMWh;

% total system + heating costs over 30 years for thermal
ThTcost = (DHWcost.*30) + (SHcost.*30) + Thsystemcost;

% cost saved from solar farm
  % capacity reduction
  capred = heat.*(37/63);
  capredcost = capred.*CpMWFarm;
  

% total system cost for PVT
PVTTcost = (DHWcost.*30) + (SHcost.*30) + PVTsystemcostw - capredcost;

% find optimal capacity
%ThTcostmin = find(Tcost == min(Tcost));
%ThOptimalCapacity = heat(Tcostmin);

figure
hold on
plot(heat,ThTcost,'b');
plot(heat,PVTTcost,'m');
xlabel('Total Thermal Panel Capacity (MW)')
ylabel('Total Heating Costs Over 30 years')
legend({'Solar Thermal','PV-T'},'Location','southeast')
hold off
