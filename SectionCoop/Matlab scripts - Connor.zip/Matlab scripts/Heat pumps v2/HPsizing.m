% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

DHW_HH = readmatrix('DHW_HH2.csv');              % DHW load
SH_HH = readmatrix('HH_spaceheating_heat.csv');  % SH load
Solar_HH1MW = readmatrix('pv_hh_pwr_1MW.csv');

% tidy up

SH_HH = SH_HH(:,2).*(18/20);
Solar_HH1MW = Solar_HH1MW(:,2);

SH_maxpwr = max(SH_HH);
DHW_maxpwr = max(DHW_HH);
THD_HH = SH_HH + DHW_HH;
maxpwr_total = max(THD_HH);

avgmaxpwr = (maxpwr_total/3500)*1000;

bed2 = SH_HH*0.227 + DHW_HH*0.273;
bed3 = SH_HH*0.27 + DHW_HH*0.286;
bed4 = SH_HH*0.342 + DHW_HH*0.295;

bed2peak = max(bed2);
bed3peak = max(bed3);
bed4peak = max(bed4);

bed2tot = sum(bed2);
bed3tot = sum(bed3);
bed4tot = sum(bed4);

Tot1 = sum(THD_HH);
Tot2 = bed2tot*3.5*0.3 + bed3tot*3.5*0.3 + bed4tot*3.5*0.4;

% solar energy per year per MW

SolarEnergy = sum(Solar_HH1MW)*0.5; % in MWh

% SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

groundoutsh = (SH_HH.*0.5).*((SCOPSH-1)/SCOPSH);   % in MWh
groundoutdhw = (DHW_HH.*0.5).*((SCOPDHW-1)/SCOPDHW);  % in MWh
groundout = groundoutsh + groundoutdhw;

% daily ground output
Dailygroundout = sum(reshape(groundout,48,365)).';
%plot(1:1:365,Dailygroundout)

% write to csv
%writematrix(Dailygroundout,'Daily_Ground_Output(MWh).csv')
