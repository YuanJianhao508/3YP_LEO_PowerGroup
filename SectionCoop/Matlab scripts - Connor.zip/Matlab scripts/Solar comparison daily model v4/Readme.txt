Version 4


Electricity savings added