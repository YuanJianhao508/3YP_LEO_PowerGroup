% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;           % cost for pure thermal
CpMWPVT = 2.5e6;         % cost for pvt 2.625
CpMWFarm = 0;        % cost for solar farm set to 0.674e6 for inclusion
Cpmborehole = 42;           % cost per m borehole
CpMWhelec = 189; 
%45*1.4;        % estimated cost per MWh electricity (189 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy

% set inflation rate and discount rate
I = 0.025;
D = 0.06;

% set SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];
pv_1MW_HH = pv_1MW.*1.1;
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';


% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
%pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
DHW = max(DHW,0);
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2).*(18/20);
SH = SH.*0.5; % power to energy

% electricity profile
elecdemand = readmatrix('HH_electricity');
elecdemand = elecdemand(2:17521,2);

%row =  find(SH<0);

SH = sum(reshape(SH,48,365)).';
SH = max(SH,0);


% initialise NPV vectors
maxheatcap = 15; %MW
step = 0.01;
heatcap = 0:step:maxheatcap;
[height, length] = size(heatcap);
initialcost = heatcap.*CpMWPVT;
farmsaving = heatcap.*CpMWFarm;

% cost over 30 years
designlifetime = 25; % in years

i = 0;

excessDHWtot = zeros(1,maxheatcap/step);
excessSHtot = zeros(1,maxheatcap/step);
heat2ground = zeros(1,maxheatcap/step);
elecsavingdirect = zeros(1,maxheatcap/step);
elecsold = zeros(1,maxheatcap/step);

for heatcap = 0:step:maxheatcap % MW of solar thermal panels
    
    i = i + 1;
    
    % panel heat
    PH = pvt_1MW.*heatcap;
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot(i) = sum(excessDHW);
    excessSHtot(i) = sum(excessSH);
    heat2ground(i) = sum(p2g);
    %test = SH - excessSH;
    
    elecnet = pv_1MW_HH.*heatcap - elecdemand;
    elecsell = max(elecnet,0);
    elecsold(i) = sum(elecsell);
    elecneg = min(elecnet,0);
    elecsavingvector = elecneg + elecdemand;
    elecsavingdirect(i) = sum(elecsavingvector);
    
end

SHsatisfied = sum(SH) - excessSHtot;
DHWsatisfied = sum(DHW) - excessDHWtot;

% borehole saving
g2sh = excessSHtot.*((SCOPSH-1)/SCOPSH);   % in MWh
g2dhw = excessDHWtot.*((SCOPDHW-1)/SCOPDHW);  % in MWh
gout = g2sh + g2dhw;
gnet = gout - heat2ground;
FLEQ = gnet./21;

p2fit = [1200 1800 2400 3000; 51 46 41 38];
Coeff = polyfit(p2fit(1,:),p2fit(2,:),2);
Wpmmax = Coeff(1).*(FLEQ.^2) + Coeff(2).*FLEQ + Coeff(3).*(FLEQ.^0);  % maximum W per m to be extracted from boreholes
G = 6000*3500*(1-(1/SCOPSH));  % max to be extracted from ground
Blength = (G)./Wpmmax; % total length of borehole
lengthsaving = Blength(1) - Blength;
boreholesaving = lengthsaving.*Cpmborehole;


% electric savings
elecsavinghp = SHsatisfied./SCOPSH + DHWsatisfied./SCOPDHW; % in MWh
heatcap = 0:step:maxheatcap;
%plot(heatcap,elecsavings)
elecsavingnet = elecsavinghp + elecsavingdirect;

eleccost = elecsavingnet.*CpMWhelec;

% electricity selling
elecsoldprice = elecsold.*CpMWhelecsell;

t = 1:1:designlifetime;
Dfactor = (1+(D-I)).^(-t);

NPVelecarray = Dfactor.'*eleccost;
NPVelecsellarray = Dfactor.'*elecsoldprice;

NPVelec = sum(NPVelecarray,1);
NPVelecsold = sum(NPVelecsellarray,1);

NPVtot = NPVelec - initialcost + farmsaving + boreholesaving + NPVelecsold;
%NPV1house = NPVtot./3500;
plot(heatcap,NPVtot)
xlabel('Total PV-T capacity (MW)')
ylabel('Net Present Value (millions of pounds)')
[v, i] = max(NPVtot);
heatcap(i)

i2MW = find(heatcap==7);

NPV2MW = NPVelecarray(:,i2MW) + NPVelecsellarray(:,i2MW);
NPV2MW = [0;NPV2MW];
NPV2MW(1) = NPV2MW(1) - initialcost(i2MW) + farmsaving(i2MW) + boreholesaving(i2MW);
NPV2MWcum = cumsum(NPV2MW)./1e6;
figure
plot(0:1:designlifetime,NPV2MWcum)
ylabel('PV (Millions of Pounds)')
xlabel('Year After Construction')
