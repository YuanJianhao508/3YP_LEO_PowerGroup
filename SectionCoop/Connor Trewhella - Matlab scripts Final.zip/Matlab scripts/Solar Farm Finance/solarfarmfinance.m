% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% capacity
Cap = 6;       % MW

% lifespan and degradation
lifespan = 25;   % expected years of operation
deg = 0.994;      % yearly degradation factor (capacity drop)

% costs
CpMWFarm = 0.350e6;        % initial cost for solar farm
CpMWhelec = 198; 
%45*1.4;        % estimated cost per MWh electricity (198 2019,202 2020, 219 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy
CpypMW = 6000;                 % upkeep cost per year per MW

% load data
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];

% revenue
year1rev = sum(pv_1MW)*Cap*CpMWhelecsell;
rev = zeros(1,lifespan);  % initialise revenue vector, holds total for each year of operation
year1exp = CpypMW*Cap;    % year 1 expenditure
exp = zeros(1,lifespan);

%for y = 1:1:lifespan
   % rev(y) = year1rev*(deg^(y-1));  % gives revenue of that year 
  %  exp(y) = year1exp;  % expenditure
%end

% costs
initialcost = CpMWFarm*Cap;

% net present value
Dmax = 0.2;
Dstep = 0.001;
Dreal = 0:Dstep:Dmax;
NPV = zeros(1,Dmax/Dstep);
iter = 0;
t = 1:1:lifespan;


for Dreal = 0:Dstep:Dmax
    iter = iter+1;
    PVrev = zeros(1,lifespan);
    PVexp = zeros(1,lifespan);
    for y = 1:1:lifespan
        Drealfactor = (1+(Dreal)).^(-y);
        PVrev(y) = year1rev*(deg^(y-1))*Drealfactor;  % gives PV of revenue of that year
        PVexp(y) = year1exp*Drealfactor;
    end
    NPV(iter) = sum(PVrev) - initialcost - sum(PVexp);
end

figure
plot(0:Dstep*100:Dmax*100,NPV./1e6)
xlabel('Real Discount Rate (%)')
ylabel('Net Present Value (Millions of Pounds)')
title('Net Present Value for a 6MW Solar Farm Installation')
grid on


% exports
% writematrix(NPV./1e6,'IRR_solarfarm_standard.csv');