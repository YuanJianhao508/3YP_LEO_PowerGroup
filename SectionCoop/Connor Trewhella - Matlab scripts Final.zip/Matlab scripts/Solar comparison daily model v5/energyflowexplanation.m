% for each capacity, plot one graph each with:
   % SH and DHW demands stacked, Supply, net
   % excess SH and DHW and flows to ground


% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;           % cost for pure thermal
CpMWPVT = 2.625e6;         % cost for pvt 2.625
CpMWFarm = 0;        % cost for solar farm set to 0.674e6 for inclusion
Cpmborehole = 42;           % cost per m borehole
CpMWhelec = 198; 
%45*1.4;        % estimated cost per MWh electricity (198 2019,202 2020, 219 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy


% set SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];
pv_1MW_HH = pv_1MW.*1.1;
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
%pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
DHW = max(DHW,0);
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2).*(18/20);
SH = SH.*0.5; % power to energy
SH = sum(reshape(SH,48,365)).';
SH = max(SH,0);

% electricity profile
elecdemand = readmatrix('HH_electricity');
elecdemand = elecdemand(2:17521,2);

% define panel heats
PH35 = pvt_1MW.*3.5;
PH7 = pvt_1MW.*7;
PH105 = pvt_1MW.*10.5;

% find heat flows
[exSH35,exDHW35,p2g35] = findheatflows(SH,DHW,PH35);
[exSH7,exDHW7,p2g7] = findheatflows(SH,DHW,PH7);
[exSH105,exDHW105,p2g105] = findheatflows(SH,DHW,PH105);

% net demand after panel heat
net35 = exSH35 + exDHW35;
net7 = exSH7 + exDHW7;
net105 = exSH105 + exDHW105;


% output vectors for heat flows
   % 3.5 MW cap, in order: total SH demand, total DHW demand; panel heat; net demand; excess
   % SH demand; excess DHW demand; flows to ground
   Cap_35 = [SH DHW PH35 net35 exSH35 exDHW35 p2g35];
   Cap_7 = [SH DHW PH7 net7 exSH7 exDHW7 p2g7];
   Cap_105 = [SH DHW PH105 net105 exSH105 exDHW105 p2g105];
   
   % write data
   writematrix(Cap_35,'Cap35pvtflows.csv');
   writematrix(Cap_7,'Cap7pvtflows.csv');
   writematrix(Cap_105,'Cap105pvtflows.csv');


% vectors for elec flows
