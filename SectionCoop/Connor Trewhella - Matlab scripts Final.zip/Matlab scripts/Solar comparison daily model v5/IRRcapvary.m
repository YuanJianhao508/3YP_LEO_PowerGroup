clear

% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;           % cost for pure thermal
CpMWPVT = 2.625e6;         % cost for pvt 2.625
CpMWFarm = 0;        % cost for solar farm set to 0.674e6 for inclusion
Cpmborehole = 42;           % cost per m borehole
CpMWhelec = 198; 
%45*1.4;        % estimated cost per MWh electricity (198 2019,202 2020, 219 2021, 280 2022)
CpMWhelecsell = 55;           % price when selling elecrical energy
Cpinverter = 500;             % cost per inverter in pounds


% set SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];
pv_1MW_HH = pv_1MW.*1.1;
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
%pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
DHW = max(DHW,0);
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2).*(18/20);
SH = SH.*0.5; % power to energy
SH = sum(reshape(SH,48,365)).';
SH = max(SH,0);

% electricity profile
elecdemand = readmatrix('HH_electricity');
elecdemand = elecdemand(2:17521,2);

% initialise NPV vectors
maxheatcap = 15; %MW
step = 0.01;
heatcap = 0:step:maxheatcap;
[height, length] = size(heatcap);
initialcost = heatcap.*CpMWPVT;
farmsaving = heatcap.*CpMWFarm;

% cost over 30 years
designlifetime = 25; % in years

i = 0;

IRR = zeros(1,maxheatcap/step);

for heatcap = 0:step:maxheatcap % MW of solar thermal panels
    
    i = i + 1;
    
    % panel heat
    PH = pvt_1MW.*heatcap;
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot = sum(excessDHW);
    excessSHtot = sum(excessSH);
    heat2ground = sum(p2g);
    %test = SH - excessSH;
    SHsatisfied = sum(SH) - excessSHtot;
    DHWsatisfied = sum(DHW) - excessDHWtot;
    
    elecnet = pv_1MW_HH.*heatcap - elecdemand;
    elecsell = max(elecnet,0);
    elecsold = sum(elecsell);
    elecneg = min(elecnet,0);
    elecsavingvector = elecneg + elecdemand;
    elecsavingdirect = sum(elecsavingvector);
    
    % calculate yearly savings
       % borehole savings
       g2sh = excessSHtot.*((SCOPSH-1)/SCOPSH);   % in MWh
       g2dhw = excessDHWtot.*((SCOPDHW-1)/SCOPDHW);  % in MWh
       gout = g2sh + g2dhw;
       gnet = gout - heat2ground;
       FLEQ = gnet./21;

       p2fit = [1200 1800 2400 3000; 51 46 41 38];
       Coeff = polyfit(p2fit(1,:),p2fit(2,:),2);
       Wpmmax = Coeff(1).*(FLEQ.^2) + Coeff(2).*FLEQ + Coeff(3).*(FLEQ.^0);  % maximum W per m to be extracted from boreholes
       G = 6000*3500*(1-(1/SCOPSH));  % max to be extracted from ground
       Blength = (G)./Wpmmax; % total length of borehole
       lengthsaving = Blength(1) - Blength;
       boreholesaving = lengthsaving.*Cpmborehole;
       
       % elecsavings from heat pump and then net price saved
       elecsavinghp = SHsatisfied./SCOPSH + DHWsatisfied./SCOPDHW; % in MWh
       elecsavingnet = elecsavinghp + elecsavingdirect;
       eleccost = elecsavingnet.*CpMWhelec;
       
       % elec sold price
       elecsoldcost = elecsold.*CpMWhelecsell;
       
       % total yearly savings
       yearlysaving = eleccost + elecsoldcost;
       
    % initial cost
    initialcost = heatcap*CpMWPVT + Cpinverter*3500;
    
    % NPV
       % NPV vector initiation
       Drealmax = 0.2;
       Drealstep = 0.0005;
       NPV = zeros(1,Drealmax/Drealstep);
       iter = 0;
       t = 1:1:25;

       for Dreal = 0:Drealstep:Drealmax
          iter = iter+1;
          Drealfactor = (1+(Dreal)).^(-t);
          NPVsavingarray = yearlysaving.*Drealfactor;
          NPV(iter) = sum(NPVsavingarray) - initialcost;
       end

    Dreal = 0:Drealstep:Drealmax;

    [IRRrow,IRRcol,NPVval] = find(NPV<=0);
    IRR(i) = Dreal(IRRcol(1));
       
    
end

plot(0:step:maxheatcap,IRR.*100)
