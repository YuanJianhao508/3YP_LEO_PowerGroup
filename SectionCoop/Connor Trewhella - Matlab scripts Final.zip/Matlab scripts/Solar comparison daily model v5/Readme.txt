Version 5


added plot of IRR against capacity

added plots of heat and electricity satisfied at different capacities