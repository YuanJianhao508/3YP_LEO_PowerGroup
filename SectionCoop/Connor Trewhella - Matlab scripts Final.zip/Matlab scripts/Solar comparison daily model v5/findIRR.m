function [IRR] = findIRR(elecsoldprice,eleccost,initialcost,boreholesaving,index)
%FINDIRR Summary of this function goes here
%   Detailed explanation goes here

Drealmax = 0.2;
Drealstep = 0.001;
NPV = zeros(1,Drealmax/Drealstep);
iter = 0;

for Dreal = 0:Drealstep:Drealmax
    iter = iter+1;
    Drealfactor = (1+(Dreal)).^(-t);
    NPVrealelecarray = Drealfactor.*eleccost(index);
    NPVrealelecsellarray = Drealfactor.*elecsoldprice(index);
    NPV(iter) = sum(NPVrealelecsellarray) + sum(NPVrealelecarray) - initialcost(index) + boreholesaving(index);
end

Dreal = 0:Drealstep:Drealmax;

[IRRrow,IRRcol,NPVval) = find(NPV<0);
IRR = Dreal(IRRrow);

end

