Version 5


added fixed cost of inverters for the houses