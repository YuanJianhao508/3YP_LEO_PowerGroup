% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

DHW_HH = readmatrix('DHW_HH2.csv');              % DHW load
SH_HH = readmatrix('HH_spaceheating_heat.csv');  % SH load
pv_1MW = readmatrix('pv_hh_pwr_1MW');            % PV profile
pv_1MW = pv_1MW(:,2);
pv_1MW = [pv_1MW; 0];
pvt_1MW = pv_1MW.*2;                             % pvt heat profile

% tidy up
SH_HH = SH_HH(:,2);
SH_HH = max(SH_HH,0).*(18/20);
DHW_HH = max(DHW_HH,0);

SH_maxpwr = max(SH_HH);
DHW_maxpwr = max(DHW_HH);
THD_HH = SH_HH + DHW_HH;        % total heating demand
maxpwr_total = max(THD_HH);

% solar energy per year per MW (in MWh)
PVTtot = sum(pvt_1MW).*0.5;

% SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

groundoutsh = (SH_HH.*0.5).*((SCOPSH-1)/SCOPSH);   % in MWh
groundoutdhw = (DHW_HH.*0.5).*((SCOPDHW-1)/SCOPDHW);  % in MWh
groundout = groundoutsh + groundoutdhw;
groundouttot = sum(groundout);

FLEQ0 = groundouttot/21;

%Pmax1200 = 51;
%Pmax1800 = 46;
%Pmax2400 = 41;
%Pmax3000 = 38;
p2fit = [1200 1800 2400 3000; 51 46 41 38];
Coeff = polyfit(p2fit(1,:),p2fit(2,:),2);

x = 0:1:4000;
y = Coeff(1).*(x.^2) + Coeff(2).*x + Coeff(3).*(x.^0);
hold on
plot(x,y)
plot(p2fit(1,:),p2fit(2,:),'x')
xlabel('FLEQ Run Hours (hours)')
ylabel('Maximum Allowable Heat Extraction (W/m)') 
legend({'Quadratic Line of Best Fit','Original Points'},'Location','northeast')