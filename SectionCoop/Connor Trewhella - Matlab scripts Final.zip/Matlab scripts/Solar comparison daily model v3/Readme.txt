Version 3


Updated input vectors

NPV implemented