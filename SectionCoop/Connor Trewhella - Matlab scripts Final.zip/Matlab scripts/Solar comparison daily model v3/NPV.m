% add relevant paths
addpath 'C:\Users\User\Documents\3YP\Data files'

% set cost per MW capacity
CpMWTh = 2.25e6;           % cost for pure thermal
CpMWPVT = 2.625e6;         % cost for pvt
CpMWFarm = 0.674e6;        % cost for solar farm
Cpmborehole = 42;           % cost per m borehole
CpMWhelec = 195; 
%45*1.4;        % estimated cost per MWh electricity (189 2021, 280 2022)

% set inflation rate and discount rate
I = 0.02;
D = 0.035;

% set SCOPs
SCOPSH = 3.45;
SCOPDHW = 2.97;

% set cost per MWh electricity
CpMWh = 45*1.5;

% load 1MW pv profile
pv_1MW = readmatrix('pv_hh_pwr_1MW');
pv_1MW = pv_1MW(:,2).*0.5;
pv_1MW = [pv_1MW; 0];
pv_1MW_HH = pv_1MW;
% change to daily
pv_1MW = sum(reshape(pv_1MW,48,365)).';


% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
%pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('DHW_HH2');
DHW = DHW.*0.5; % power to energy
DHW = sum(reshape(DHW,48,365)).';
DHW = max(DHW,0);
SH = readmatrix('HH_spaceheating_heat');
SH = SH(:,2).*(18/20);
SH = SH.*0.5; % power to energy

% electricity profile
Elecdemand = readmatrix('HH_electricity');

%row =  find(SH<0);

SH = sum(reshape(SH,48,365)).';
SH = max(SH,0);


% initialise NPV vectors
maxheatcap = 10; %MW
step = 0.01;
heatcap = 0:step:maxheatcap;
[height, length] = size(heatcap);
initialcost = heatcap.*CpMWPVT;
farmsaving = heatcap.*CpMWFarm;

% cost over 30 years
designlifetime = 30; % in years

i = 0;

excessDHWtot = zeros(1,maxheatcap/step);
excessSHtot = zeros(1,maxheatcap/step);
heat2ground = zeros(1,maxheatcap/step);

for heatcap = 0:step:maxheatcap % MW of solar thermal panels
    
    i = i + 1;
    
    % panel heat
    PH = pvt_1MW.*heatcap;
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot(i) = sum(excessDHW);
    excessSHtot(i) = sum(excessSH);
    heat2ground(i) = sum(p2g);
    %test = SH - excessSH;
    
    
    
end

SHsatisfied = sum(SH) - excessSHtot;
DHWsatisfied = sum(DHW) - excessDHWtot;

% borehole saving
g2sh = excessSHtot.*((SCOPSH-1)/SCOPSH);   % in MWh
g2dhw = excessDHWtot.*((SCOPDHW-1)/SCOPDHW);  % in MWh
gout = g2sh + g2dhw;
gnet = gout - heat2ground;
FLEQ = gnet./21;

p2fit = [1200 1800 2400 3000; 51 46 41 38];
Coeff = polyfit(p2fit(1,:),p2fit(2,:),2);
Wpmmax = Coeff(1).*(FLEQ.^2) + Coeff(2).*FLEQ + Coeff(3).*(FLEQ.^0);  % maximum W per m to be extracted from boreholes
G = 6000*3500*(1-(1/SCOPSH));  % max to be extracted from ground
Blength = (G)./Wpmmax; % total length of borehole
lengthsaving = Blength(1) - Blength;
boreholesaving = lengthsaving.*Cpmborehole;


% electric savings
elecsavings = SHsatisfied./SCOPSH + DHWsatisfied./SCOPDHW; % in MWh
heatcap = 0:step:maxheatcap;
%plot(heatcap,elecsavings)

eleccost = elecsavings.*CpMWhelec;

t = 1:1:designlifetime;
Dfactor = (1+(D-I)).^(-t);

NPVelecarray = Dfactor.'*eleccost;

NPVelec = sum(NPVelecarray,1);

NPVtot = NPVelec - initialcost + farmsaving + boreholesaving;
plot(heatcap,NPVtot)
[v, i] = max(NPVtot);
heatcap(i)

