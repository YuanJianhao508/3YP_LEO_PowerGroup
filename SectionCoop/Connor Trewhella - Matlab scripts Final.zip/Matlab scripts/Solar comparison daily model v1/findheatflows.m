function [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH)
%FINDHEATFLOWS finds excess heating demands and flow to ground
% SH - space heating, DHW - domestic hot water, PH - panel heat

p2DHW = DHW-PH;
excessDHW = max(p2DHW,0);

PH2 = min(p2DHW,0).*(-1);

p2SH = SH-PH2;
excessSH = max(p2SH,0);

p2g = min(p2SH,0).*(-1);

end

