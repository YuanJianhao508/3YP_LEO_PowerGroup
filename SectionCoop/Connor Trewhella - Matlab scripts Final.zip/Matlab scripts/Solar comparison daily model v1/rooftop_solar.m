% add relevant paths
addpath 'C:\Users\User\Documents\3YP\data files'

% load 1MW pv profile
pv_1MW = readmatrix('pv_d_energy');
pv_1MW = pv_1MW(:,2);

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW(:,2) = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('daily_DHW_power');
DHW = DHW.';
DHW = DHW.*24;  % power to energy
SH = readmatrix('heating_daily_power');
SH = SH(:,2);
SH = SH.*3; % the original was in electricity not heat
SH = SH.*24; % power to energy

% scale heat demands
DHW = DHW.*(176.94e6);


% define 

