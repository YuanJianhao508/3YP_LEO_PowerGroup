% add relevant paths
addpath 'C:\Users\User\Documents\3YP\data files'

% set cost per MW capacity
CpMWT = 1.5e6;            % cost for pure thermal
CpMWPVT = 2.25e6;         % cost for pvt

% set cost per MWh electricity
CpMWh = 45*1.5;

% load 1MW pv profile
pv_1MW = readmatrix('pv_d_energy');
pv_1MW = pv_1MW(:,2);

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW(:,2) = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('daily_DHW_power');
DHW = DHW.';
%DHW = DHW.*24;  % power to energy
SH = readmatrix('heating_daily_power');
SH = SH(:,2);
%SH = SH.*3; % the original was in electricity not heat
%SH = SH.*24; % power to energy
SH = SH(1:365,:);

% scale heat demands
DHW = DHW.*((5.2e3)/sum(DHW));
SH = SH.*((21.1e3)/sum(SH));

% total heating demands
DHWtot = sum(DHW);
SHtot = sum(SH);

% define amounts of heat
% initialise vectors
hmax = 18;
heat = 0:0.1:hmax;
heatlength = length(heat);
excessDHWtot = zeros(1,heatlength);
excessSHtot = zeros(1,heatlength);
heat2ground = zeros(1,heatlength);
systemcost = zeros(1,heatlength);

for i = 1:heatlength % MW of solar thermal panels
    
    % panel heat
    PH = st_1MW.*heat(i);
    
    [excessSH,excessDHW,p2g] = findheatflows(SH,DHW,PH);
    
    excessDHWtot(i) = sum(excessDHW);
    excessSHtot(i) = sum(excessSH);
    heat2ground(i) = sum(p2g);
    
    systemcost(i) = heat(i)*CpMWT;
    
end

% electrical energy costs
DHWenergy = excessDHWtot./2.2;
SHenergy = excessSHtot./3.2;

DHWcost = DHWenergy.*CpMWh;
SHcost = SHenergy.*CpMWh;

% total system + heating costs over 30 years
Tcost = (DHWcost.*30) + (SHcost.*30) + systemcost;

% find optimal capacity
Tcostmin = find(Tcost == min(Tcost));
OptimalCapacity = heat(Tcostmin);

figure
plot(heat,Tcost,'b');
xlabel('Total Thermal Panel Capacity (MW)')
ylabel('Total Heating Costs Over 30 years')
