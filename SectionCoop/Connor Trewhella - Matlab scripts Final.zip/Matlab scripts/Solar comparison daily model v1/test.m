% add relevant paths
addpath 'C:\Users\User\Documents\3YP\data files'

% load 1MW pv profile
pv_1MW = readmatrix('pv_d_energy');
pv_1MW = pv_1MW(:,2);

% get solar thermal (st) and PVT (pvt) profiles
st_1MW = pv_1MW.*(0.9/0.128);
pvt_1MW(:,1) = pv_1MW.*1.1;
pvt_1MW(:,2) = pv_1MW.*2;

% load demand profiles
DHW = readmatrix('daily_DHW_power');
DHW = DHW.';
SH = readmatrix('heating_daily_power');
SH = SH(:,2);
SH = SH.*3; % the original was in electricity not heat
SH = SH(1:365,:);  % one extra day for some reason

PH = st_1MW;

p2DHW = DHW - PH;
excessDHW = max(p2DHW,0);

PH2 = min(p2DHW,0).*(-1);

p2SH = SH - PH2;
excessSH = max(p2SH,0);

p2g = min(p2SH,0).*(-1);
